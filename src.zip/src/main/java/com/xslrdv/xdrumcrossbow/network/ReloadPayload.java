package com.xslrdv.xdrumcrossbow.network;

import com.xslrdv.xdrumcrossbow.XDrumCrossbow;
import com.xslrdv.xdrumcrossbow.item.DrumCrossbowItem;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Клиент -> сервер: игрок нажал R. */
public record ReloadPayload() implements CustomPacketPayload {
    public static final Type<ReloadPayload> TYPE =
        new Type<>(Identifier.fromNamespaceAndPath(XDrumCrossbow.MODID, "reload"));
    public static final StreamCodec<ByteBuf, ReloadPayload> CODEC = StreamCodec.unit(new ReloadPayload());

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(ReloadPayload payload, IPayloadContext ctx) {
        Player player = ctx.player();
        ItemStack stack = player.getMainHandItem();
        if (!(stack.getItem() instanceof DrumCrossbowItem)) return;

        int current = DrumCrossbowItem.getAmmo(stack);
        int need = DrumCrossbowItem.MAX_AMMO - current;
        if (need <= 0) return;

        int taken = 0;
        if (player.getAbilities().instabuild) {
            taken = need; // в творческом режиме стрелы бесплатные
        } else {
            Inventory inv = player.getInventory();
            for (int i = 0; i < inv.getContainerSize() && taken < need; i++) {
                ItemStack s = inv.getItem(i);
                if (s.is(Items.ARROW)) {
                    int t = Math.min(s.getCount(), need - taken);
                    s.shrink(t);
                    taken += t;
                }
            }
        }

        if (taken > 0) {
            DrumCrossbowItem.setAmmo(stack, current + taken);
            player.level().playSound(null, player.blockPosition(),
                SoundEvents.CROSSBOW_LOADING_END.value(), SoundSource.PLAYERS, 1f, 1f);
        }
    }
}
