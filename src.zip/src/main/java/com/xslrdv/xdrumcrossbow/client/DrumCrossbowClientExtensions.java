package com.xslrdv.xdrumcrossbow.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.xslrdv.xdrumcrossbow.item.DrumCrossbowItem;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.renderer.state.level.PlayerRenderState;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.client.extensions.common.IClientItemExtensions;
import org.joml.Matrix4f;

public class DrumCrossbowClientExtensions implements IClientItemExtensions {

    /** Поза рук в третьем лице: как у ванильного арбалета. */
    @Override
    public HumanoidModel.ArmPose getArmPose(LivingEntity entity, InteractionHand hand, ItemStack stack) {
        return HumanoidModel.ArmPose.CROSSBOW_HOLD;
    }

    /** Положение предмета в первом лице + отдача. Возврат true = ванильный сдвиг не применяется. */
    @Override
    public boolean applyForgeHandTransform(PoseStack poseStack, PlayerRenderState playerState, HumanoidArm arm,
                                           ItemStack stack, float partialTick, float equipProcess, float swingProcess) {
        int side = arm == HumanoidArm.RIGHT ? 1 : -1;

        // То же, что делает ваниль в applyItemArmTransform (качания от удара у нас нет)
        poseStack.translate(side * 0.56f, -0.52f + equipProcess * -0.6f, -0.72f);

        float k = ClientRecoil.get(partialTick);
        if (k > 0f) {
            // В 26.x сюда приходит render state, а не сам игрок; это всегда локальный игрок
            boolean aim = DrumCrossbowItem.isAiming(Minecraft.getInstance().player);
            float back = aim ? ClientRecoil.AIM_BACK : ClientRecoil.HIP_BACK;
            float up = aim ? ClientRecoil.AIM_UP : ClientRecoil.HIP_UP;
            float pitch = aim ? ClientRecoil.AIM_PITCH : ClientRecoil.HIP_PITCH;

            poseStack.translate(0f, up * k, back * k);
            poseStack.mulPose(new Matrix4f().rotationX((float) Math.toRadians(pitch * k)));
        }
        return true;
    }
}