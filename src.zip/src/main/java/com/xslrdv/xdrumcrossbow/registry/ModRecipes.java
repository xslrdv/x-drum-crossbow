package com.xslrdv.xdrumcrossbow.registry;

import com.xslrdv.xdrumcrossbow.XDrumCrossbow;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModRecipes {
    public static final DeferredRegister<RecipeSerializer<?>> SERIALIZERS =
        DeferredRegister.create(Registries.RECIPE_SERIALIZER, XDrumCrossbow.MODID);

    public static void register(IEventBus bus) {
        SERIALIZERS.register(bus);
    }
}
