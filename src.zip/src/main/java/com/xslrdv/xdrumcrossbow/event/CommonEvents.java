package com.xslrdv.xdrumcrossbow.event;

import com.xslrdv.xdrumcrossbow.XDrumCrossbow;
import com.xslrdv.xdrumcrossbow.item.DrumCrossbowItem;

import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.AttackEntityEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/** Арбалет в руке не должен ломать блоки и бить врукопашную: ЛКМ только стреляет. */
@EventBusSubscriber(modid = XDrumCrossbow.MODID)
public class CommonEvents {
    @SubscribeEvent
    public static void onLeftClickBlock(PlayerInteractEvent.LeftClickBlock e) {
        if (e.getEntity().getMainHandItem().getItem() instanceof DrumCrossbowItem) {
            e.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onAttackEntity(AttackEntityEvent e) {
        if (e.getEntity().getMainHandItem().getItem() instanceof DrumCrossbowItem) {
            e.setCanceled(true);
        }
    }
}
