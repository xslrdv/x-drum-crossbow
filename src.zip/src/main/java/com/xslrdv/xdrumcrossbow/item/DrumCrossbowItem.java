package com.xslrdv.xdrumcrossbow.item;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.xslrdv.xdrumcrossbow.registry.ModComponents;

import net.minecraft.core.component.DataComponents;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.arrow.AbstractArrow;
import net.minecraft.world.entity.projectile.arrow.Arrow;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUseAnimation;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomModelData;
import net.minecraft.world.item.component.UseEffects;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

public class DrumCrossbowItem extends Item {
    public static final int MAX_AMMO = 10;
    public static final int FIRE_DELAY = 6;         // тиков между выстрелами (~3/сек)
    public static final int EMPTY_CLICK_DELAY = 20; // как часто щёлкает пустой барабан

    public static final float ARROW_SPEED = 3.15f;
    public static final float AIM_INACCURACY = 0.4f; // разброс при прицеливании (ПКМ)
    public static final float HIP_INACCURACY = 2.5f; // разброс "от бедра"

    /**
     * Множитель скорости при прицеливании (ПКМ): 1.0 = без замедления,
     * 0.7 = медленнее на 30%, 0.5 = на 50%. Ваниль для использования предметов даёт 0.2.
     */
    public static final float AIM_SPEED_MULTIPLIER = 0.7f;

    // Откуда вылетает стрела "от бедра" (относительно глаз игрока, в блоках)
    public static final double HIP_SIDE = 0.35;     // вправо
    public static final double HIP_DOWN = 0.25;     // вниз
    public static final double HIP_FORWARD = 0.5;   // вперёд
    // На каком расстоянии траектория стрелы пересекает линию прицела
    public static final double CONVERGE_DISTANCE = 30.0;

    /** Игрок -> игровое время последнего выстрела (живёт только на сервере). */
    private static final Map<UUID, Long> LAST_SHOT = new HashMap<>();

    public DrumCrossbowItem(Properties props) {
        super(props
            .stacksTo(1)
            // (can_sprint, interact_vibrations, speed_multiplier)
            .component(DataComponents.USE_EFFECTS, new UseEffects(false, true, AIM_SPEED_MULTIPLIER)));
    }

    // ---- ПКМ: прицеливание ----------------------------------------------

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        player.startUsingItem(hand);
        return InteractionResult.CONSUME;
    }

    @Override
    public int getUseDuration(ItemStack stack, LivingEntity entity) {
        return 72000;
    }

    @Override
    public ItemUseAnimation getUseAnimation(ItemStack stack) {
        return ItemUseAnimation.NONE;
    }

    /** Смена компонентов (патроны, модель) не должна запускать анимацию "достаёт предмет". */
    @Override
    public boolean shouldCauseReequipAnimation(ItemStack oldStack, ItemStack newStack, boolean slotChanged) {
        return slotChanged || !oldStack.is(newStack.getItem());
    }

    /** Прицеливание не должно прерываться, когда после выстрела меняется стак. */
    @Override
    public boolean canContinueUsing(ItemStack oldStack, ItemStack newStack) {
        return oldStack.is(newStack.getItem());
    }

    public static boolean isAiming(Player player) {
        return player.isUsingItem() && player.getUseItem().getItem() instanceof DrumCrossbowItem;
    }

    // ---- патроны ----------------------------------------------------------

    public static int getAmmo(ItemStack stack) {
        return stack.getOrDefault(ModComponents.AMMO.get(), 0);
    }

    /** Единственное место, где меняется количество стрел (+ флаг для JSON-модели). */
    public static void setAmmo(ItemStack stack, int ammo) {
        ammo = Mth.clamp(ammo, 0, MAX_AMMO);
        stack.set(ModComponents.AMMO.get(), ammo);
        stack.set(DataComponents.CUSTOM_MODEL_DATA,
            new CustomModelData(List.of(), List.of(ammo > 0), List.of(), List.of()));
    }

    // ---- ЛКМ: выстрел -----------------------------------------------------

    /** Вызывается на сервере, пока игрок держит ЛКМ. */
    public static void tryShoot(Player player) {
        ItemStack stack = player.getMainHandItem();
        if (!(stack.getItem() instanceof DrumCrossbowItem)) return;

        Level level = player.level();
        long now = level.getGameTime();
        Long last = LAST_SHOT.get(player.getUUID());
        if (last != null && now - last < FIRE_DELAY) return;

        int ammo = getAmmo(stack);
        if (ammo <= 0) {
            if (last == null || now - last >= EMPTY_CLICK_DELAY) {
                LAST_SHOT.put(player.getUUID(), now);
                level.playSound(null, player.blockPosition(), SoundEvents.DISPENSER_FAIL,
                    SoundSource.PLAYERS, 1f, 1f);
            }
            return;
        }
        LAST_SHOT.put(player.getUUID(), now);

        Arrow arrow = new Arrow(level, player, new ItemStack(Items.ARROW), stack);
        if (isAiming(player)) {
            // Прицеливание: из центра экрана, точно по взгляду
            arrow.shootFromRotation(player, player.getXRot(), player.getYRot(), 0f, ARROW_SPEED, AIM_INACCURACY);
        } else {
            shootFromHip(player, arrow);
        }
        if (player.getAbilities().instabuild) {
            arrow.pickup = AbstractArrow.Pickup.CREATIVE_ONLY;
        }
        level.addFreshEntity(arrow);

        level.playSound(null, player.blockPosition(), SoundEvents.CROSSBOW_SHOOT,
            SoundSource.PLAYERS, 1f, 1f);

        setAmmo(stack, ammo - 1);
        // износ прочности добавим позже
    }

    /** Стрела вылетает из позиции арбалета в руке и летит в точку, на которую смотрит прицел. */
    private static void shootFromHip(Player player, Arrow arrow) {
        Level level = player.level();
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle();

        double yaw = Math.toRadians(player.getYRot());
        Vec3 right = new Vec3(-Math.cos(yaw), 0, -Math.sin(yaw)); // вправо от взгляда
        Vec3 up = right.cross(look);
        double side = player.getMainArm() == HumanoidArm.LEFT ? -1 : 1;

        Vec3 spawn = eye
            .add(right.scale(HIP_SIDE * side))
            .add(up.scale(-HIP_DOWN))
            .add(look.scale(HIP_FORWARD));

        // Точка, в которую целится крестик (ближайший блок или максимальная дистанция)
        Vec3 end = eye.add(look.scale(CONVERGE_DISTANCE));
        BlockHitResult hit = level.clip(
            new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        Vec3 dir = hit.getLocation().subtract(spawn);
        if (dir.lengthSqr() < 0.25) dir = look;

        arrow.setPos(spawn.x, spawn.y, spawn.z);
        arrow.shoot(dir.x, dir.y, dir.z, ARROW_SPEED, HIP_INACCURACY);
    }
}
